using UnityEngine;

public class SunPosition : MonoBehaviour
{
    public float rate = 1f;
    public GameObject mainCamera;
    Skybox skyBox;

    void Start()
    {
        skyBox = mainCamera.GetComponent<Skybox>();
    }

    void Update()
    {
        this.transform.Rotate(0, rate, 0, Space.World);
	//skyBox.transform.Rotate(0, rate, 0, Space.World);
    }
}
